namespace Urok5;

public class Person
{
    private static int _nextId = 1;

    public int Id { get; private set; }

    public string Name { get; set; } = string.Empty;

    public Person()
    {
        Id = _nextId++;
    }
}
