namespace Urok5;

public class Student : Person
{
    public int Grade { get; set; }
}
