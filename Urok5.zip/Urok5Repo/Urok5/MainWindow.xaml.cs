using System.Windows;

namespace Urok5;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private Student? ReadStudent()
    {
        if (string.IsNullOrWhiteSpace(NameBox.Text))
        {
            ResultText.Text = "Въведете име.";
            return null;
        }

        if (!int.TryParse(GradeBox.Text, out int grade))
        {
            ResultText.Text = "Оценката трябва да е цяло число.";
            return null;
        }

        Student s = new Student();
        s.Name = NameBox.Text.Trim();
        s.Grade = grade;
        return s;
    }

    private void CreateButton_Click(object sender, RoutedEventArgs e)
    {
        Student? s = ReadStudent();
        if (s == null)
        {
            return;
        }

        ResultText.Text = $"Student №{s.Id}: {s.Name}, оценка {s.Grade}";
    }

    private void PersonButton_Click(object sender, RoutedEventArgs e)
    {
        Student? s = ReadStudent();
        if (s == null)
        {
            return;
        }

        Person p = s;
        ResultText.Text = $"През типа Person се виждат само Id ({p.Id}) и Name ({p.Name}). Реалният тип на обекта е {p.GetType().Name}.";
    }
}
