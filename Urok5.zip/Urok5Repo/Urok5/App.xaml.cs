using System.Windows;

namespace Urok5;

public partial class App : Application
{
}
